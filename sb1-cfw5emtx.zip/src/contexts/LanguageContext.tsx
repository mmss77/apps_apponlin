import React, { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Navigation
    home: 'Home',
    about: 'About',
    gallery: 'Gallery',
    contact: 'Contact',
    
    // Hero Section
    heroTitle: 'Discover the Rose City',
    heroSubtitle: 'Petra, Jordan',
    heroDescription: 'Journey through time in one of the world\'s most magnificent archaeological sites. Experience the wonder of Petra, where ancient Nabataean civilization meets breathtaking natural beauty.',
    contactBook: 'Contact & Book',
    moreDetails: 'More Details',
    
    // About Section
    aboutTitle: 'About Petra',
    aboutDescription: 'Petra, originally known to its inhabitants as Raqmu or Raqēmō, is a historic and archaeological city in southern Jordan. Famous for its rock-cut architecture and water conduit system, Petra is also called the "Rose City" because of the color of the stone from which it is carved.',
    
    // Details Section
    detailsTitle: 'Explore Petra in Detail',
    historyTitle: 'Historical Significance',
    historyText: 'Petra was established as early as the 4th century BC as the capital city of the Nabataean Kingdom. The Nabataeans were nomadic Arabs who invested in Petra\'s proximity to the incense trade routes by establishing it as a major regional trading hub.',
    architectureTitle: 'Magnificent Architecture',
    architectureText: 'The site features over 800 individual monuments, including buildings, tombs, baths, funerary halls, temples, arched gateways, and colonnaded streets carved from the sandstone cliffs.',
    conservationTitle: 'UNESCO World Heritage',
    conservationText: 'Designated as a UNESCO World Heritage Site in 1985, Petra is Jordan\'s most-visited tourist attraction. It represents one of the world\'s most famous archaeological sites.',
    
    // Gallery
    galleryTitle: 'Photo Gallery',
    
    // Testimonials
    testimonialsTitle: 'Visitor Experiences',
    testimonial1: '"Absolutely breathtaking! The Treasury at sunrise is a moment I\'ll never forget. Petra exceeded all my expectations."',
    testimonial1Author: 'Sarah Johnson, Travel Blogger',
    testimonial2: '"Walking through the Siq and seeing the Treasury emerge is magical. The history and craftsmanship are incredible."',
    testimonial2Author: 'Ahmed Al-Rashid, Archaeologist',
    testimonial3: '"A must-visit destination. The scale and preservation of Petra is remarkable. Plan to spend at least two days here."',
    testimonial3Author: 'Maria Rodriguez, Photographer',
    
    // Contact
    contactTitle: 'Plan Your Visit',
    contactDescription: 'Ready to experience the wonder of Petra? Contact us to plan your perfect journey to the Rose City.',
    name: 'Name',
    email: 'Email',
    message: 'Message',
    sendMessage: 'Send Message',
    
    // Footer
    footerDescription: 'Discover the ancient wonder of Petra, where history comes alive in the heart of Jordan.',
    quickLinks: 'Quick Links',
    followUs: 'Follow Us',
    rights: 'All rights reserved.',
  },
  ar: {
    // Navigation
    home: 'الرئيسية',
    about: 'حول',
    gallery: 'المعرض',
    contact: 'اتصل بنا',
    
    // Hero Section
    heroTitle: 'اكتشف المدينة الوردية',
    heroSubtitle: 'البتراء، الأردن',
    heroDescription: 'رحلة عبر الزمن في واحد من أروع المواقع الأثرية في العالم. اختبر عجائب البتراء، حيث تلتقي الحضارة النبطية القديمة بالجمال الطبيعي الخلاب.',
    contactBook: 'اتصل واحجز',
    moreDetails: 'المزيد من التفاصيل',
    
    // About Section
    aboutTitle: 'حول البتراء',
    aboutDescription: 'البتراء، المعروفة أصلاً لسكانها باسم رقمو أو رقيمو، هي مدينة تاريخية وأثرية في جنوب الأردن. مشهورة بعمارتها المنحوتة في الصخر ونظام قنوات المياه، تُسمى البتراء أيضاً "المدينة الوردية" بسبب لون الحجر المنحوتة منه.',
    
    // Details Section
    detailsTitle: 'استكشف البتراء بالتفصيل',
    historyTitle: 'الأهمية التاريخية',
    historyText: 'تأسست البتراء في وقت مبكر من القرن الرابع قبل الميلاد كعاصمة للمملكة النبطية. كان الأنباط عرباً رُحّلاً استثمروا في قرب البتراء من طرق تجارة البخور من خلال إنشائها كمركز تجاري إقليمي رئيسي.',
    architectureTitle: 'العمارة الرائعة',
    architectureText: 'يضم الموقع أكثر من 800 نصب فردي، بما في ذلك المباني والمقابر والحمامات وقاعات الجنائز والمعابد والبوابات المقوسة والشوارع ذات الأعمدة المنحوتة من منحدرات الحجر الرملي.',
    conservationTitle: 'التراث العالمي لليونسكو',
    conservationText: 'تم تصنيف البتراء كموقع تراث عالمي لليونسكو في عام 1985، وهي الوجهة السياحية الأكثر زيارة في الأردن. تمثل واحداً من أشهر المواقع الأثرية في العالم.',
    
    // Gallery
    galleryTitle: 'معرض الصور',
    
    // Testimonials
    testimonialsTitle: 'تجارب الزوار',
    testimonial1: '"مذهل تماماً! الخزنة عند شروق الشمس لحظة لن أنساها أبداً. فاقت البتراء كل توقعاتي."',
    testimonial1Author: 'سارة جونسون، مدونة سفر',
    testimonial2: '"المشي عبر السيق ورؤية الخزنة تظهر أمر سحري. التاريخ والحرفية لا يصدقان."',
    testimonial2Author: 'أحمد الراشد، عالم آثار',
    testimonial3: '"وجهة يجب زيارتها. حجم وحفظ البتراء مذهل. خطط لقضاء يومين على الأقل هنا."',
    testimonial3Author: 'ماريا رودريغيز، مصورة',
    
    // Contact
    contactTitle: 'خطط لزيارتك',
    contactDescription: 'مستعد لتجربة عجائب البتراء؟ اتصل بنا لتخطيط رحلتك المثالية إلى المدينة الوردية.',
    name: 'الاسم',
    email: 'البريد الإلكتروني',
    message: 'الرسالة',
    sendMessage: 'إرسال الرسالة',
    
    // Footer
    footerDescription: 'اكتشف عجائب البتراء القديمة، حيث يعيش التاريخ في قلب الأردن.',
    quickLinks: 'روابط سريعة',
    followUs: 'تابعنا',
    rights: 'جميع الحقوق محفوظة.',
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <div className={language === 'ar' ? 'rtl' : 'ltr'} dir={language === 'ar' ? 'rtl' : 'ltr'}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};