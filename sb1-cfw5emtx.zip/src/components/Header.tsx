import React, { useState } from 'react';
import { Menu, X, Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm shadow-lg">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <motion.div 
            className="flex items-center space-x-2"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="w-8 h-8 bg-gradient-to-br from-rose-500 to-orange-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">P</span>
            </div>
            <span className={`font-bold text-xl bg-gradient-to-r from-rose-600 to-orange-600 bg-clip-text text-transparent ${language === 'ar' ? 'font-arabic' : ''}`}>
              Petra
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('home')}
              className={`text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
            >
              {t('home')}
            </button>
            <button 
              onClick={() => scrollToSection('about')}
              className={`text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
            >
              {t('about')}
            </button>
            <button 
              onClick={() => scrollToSection('gallery')}
              className={`text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
            >
              {t('gallery')}
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className={`text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
            >
              {t('contact')}
            </button>
          </nav>

          {/* Language Toggle & Mobile Menu Button */}
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-gradient-to-r from-rose-500 to-orange-500 text-white hover:from-rose-600 hover:to-orange-600 transition-all duration-200"
            >
              <Globe size={16} />
              <span className="text-sm font-medium">{language === 'en' ? 'العربية' : 'English'}</span>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-gray-700 hover:text-rose-600 transition-colors duration-200"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.nav
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden py-4 border-t border-gray-200"
            >
              <div className="flex flex-col space-y-4">
                <button 
                  onClick={() => scrollToSection('home')}
                  className={`text-left text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {t('home')}
                </button>
                <button 
                  onClick={() => scrollToSection('about')}
                  className={`text-left text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {t('about')}
                </button>
                <button 
                  onClick={() => scrollToSection('gallery')}
                  className={`text-left text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {t('gallery')}
                </button>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className={`text-left text-gray-700 hover:text-rose-600 transition-colors duration-200 ${language === 'ar' ? 'font-arabic text-right' : ''}`}
                >
                  {t('contact')}
                </button>
              </div>
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};

export default Header;