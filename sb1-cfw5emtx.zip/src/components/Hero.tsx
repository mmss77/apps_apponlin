import React from 'react';
import { MessageCircle, ChevronDown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'framer-motion';

const Hero = () => {
  const { language, t } = useLanguage();

  const scrollToDetails = () => {
    const element = document.getElementById('details');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleContactClick = () => {
    window.open('https://wa.me/962123456789?text=Hello, I would like to book a tour to Petra', '_blank');
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/5912320/pexels-photo-5912320.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Petra Treasury"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
        >
          <h1 className={`text-5xl sm:text-6xl lg:text-7xl font-bold mb-4 leading-tight ${language === 'ar' ? 'font-arabic' : ''}`}>
            {t('heroTitle')}
          </h1>
          <h2 className={`text-2xl sm:text-3xl lg:text-4xl text-rose-300 mb-8 font-light ${language === 'ar' ? 'font-arabic' : ''}`}>
            {t('heroSubtitle')}
          </h2>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4 }}
          className={`text-lg sm:text-xl lg:text-2xl mb-12 max-w-3xl mx-auto leading-relaxed text-gray-100 ${language === 'ar' ? 'font-arabic' : ''}`}
        >
          {t('heroDescription')}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center"
        >
          <button
            onClick={handleContactClick}
            className={`group px-8 py-4 bg-gradient-to-r from-rose-500 to-orange-500 text-white font-semibold rounded-full hover:from-rose-600 hover:to-orange-600 transform hover:scale-105 transition-all duration-300 shadow-2xl hover:shadow-rose-500/25 flex items-center space-x-3 ${language === 'ar' ? 'font-arabic flex-row-reverse space-x-reverse' : ''}`}
          >
            <MessageCircle className="group-hover:rotate-12 transition-transform duration-300" size={20} />
            <span className="text-lg">{t('contactBook')}</span>
          </button>

          <button
            onClick={scrollToDetails}
            className={`group px-8 py-4 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-gray-900 transform hover:scale-105 transition-all duration-300 ${language === 'ar' ? 'font-arabic' : ''}`}
          >
            <span className="text-lg">{t('moreDetails')}</span>
          </button>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-white cursor-pointer"
          onClick={scrollToDetails}
        >
          <ChevronDown size={32} />
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Hero;