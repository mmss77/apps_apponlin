import React from 'react';
import { Facebook, Instagram, Twitter, Youtube } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Footer = () => {
  const { language, t } = useLanguage();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-rose-500 to-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">P</span>
              </div>
              <span className={`font-bold text-2xl bg-gradient-to-r from-rose-400 to-orange-400 bg-clip-text text-transparent ${language === 'ar' ? 'font-arabic' : ''}`}>
                Petra
              </span>
            </div>
            <p className={`text-gray-400 leading-relaxed max-w-md ${language === 'ar' ? 'font-arabic' : ''}`}>
              {t('footerDescription')}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className={`font-semibold text-lg mb-4 ${language === 'ar' ? 'font-arabic' : ''}`}>
              {t('quickLinks')}
            </h3>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('home')}
                  className={`text-gray-400 hover:text-rose-400 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
                >
                  {t('home')}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('about')}
                  className={`text-gray-400 hover:text-rose-400 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
                >
                  {t('about')}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('gallery')}
                  className={`text-gray-400 hover:text-rose-400 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
                >
                  {t('gallery')}
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className={`text-gray-400 hover:text-rose-400 transition-colors duration-200 ${language === 'ar' ? 'font-arabic' : ''}`}
                >
                  {t('contact')}
                </button>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className={`font-semibold text-lg mb-4 ${language === 'ar' ? 'font-arabic' : ''}`}>
              {t('followUs')}
            </h3>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center hover:scale-110 transition-transform duration-200">
                <Facebook size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-gradient-to-br from-pink-500 to-rose-500 rounded-lg flex items-center justify-center hover:scale-110 transition-transform duration-200">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-gradient-to-br from-sky-500 to-blue-500 rounded-lg flex items-center justify-center hover:scale-110 transition-transform duration-200">
                <Twitter size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-lg flex items-center justify-center hover:scale-110 transition-transform duration-200">
                <Youtube size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className={`text-gray-400 ${language === 'ar' ? 'font-arabic' : ''}`}>
            © 2024 Petra Tourism. {t('rights')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;