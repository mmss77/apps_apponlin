import React from 'react';
import { Clock, Building, Award } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'framer-motion';

const Details = () => {
  const { language, t } = useLanguage();

  const features = [
    {
      icon: Clock,
      title: t('historyTitle'),
      description: t('historyText'),
      gradient: 'from-rose-500 to-pink-500'
    },
    {
      icon: Building,
      title: t('architectureTitle'),
      description: t('architectureText'),
      gradient: 'from-orange-500 to-red-500'
    },
    {
      icon: Award,
      title: t('conservationTitle'),
      description: t('conservationText'),
      gradient: 'from-amber-500 to-orange-500'
    }
  ];

  return (
    <section id="details" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className={`text-4xl lg:text-5xl font-bold mb-6 bg-gradient-to-r from-rose-600 to-orange-600 bg-clip-text text-transparent ${language === 'ar' ? 'font-arabic' : ''}`}>
            {t('detailsTitle')}
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 hover:border-rose-200 h-full">
                <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className="text-white" size={28} />
                </div>
                
                <h3 className={`text-2xl font-bold mb-4 text-gray-800 ${language === 'ar' ? 'font-arabic' : ''}`}>
                  {feature.title}
                </h3>
                
                <p className={`text-gray-600 leading-relaxed ${language === 'ar' ? 'font-arabic' : ''}`}>
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Interactive Map Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20"
        >
          <div className="bg-gradient-to-br from-rose-50 to-orange-50 rounded-3xl p-8 lg:p-12">
            <div className="text-center mb-8">
              <h3 className={`text-3xl font-bold mb-4 text-gray-800 ${language === 'ar' ? 'font-arabic' : ''}`}>
                {language === 'ar' ? 'موقع البتراء' : 'Petra Location'}
              </h3>
              <p className={`text-gray-600 ${language === 'ar' ? 'font-arabic' : ''}`}>
                {language === 'ar' ? 'تقع البتراء في محافظة معان جنوب الأردن' : 'Located in Ma\'an Governorate, southern Jordan'}
              </p>
            </div>
            
            <div className="aspect-video rounded-2xl overflow-hidden shadow-2xl">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3516.6543366833996!2d35.43983231508326!3d30.32844518179434!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15016ef04b9e8d6b%3A0x9e43c69aa9c6d35f!2sPetra%2C%20Jordan!5e0!3m2!1sen!2s!4v1635000000000!5m2!1sen!2s"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Details;