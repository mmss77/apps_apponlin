import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { motion } from 'framer-motion';

const About = () => {
  const { language, t } = useLanguage();

  return (
    <section id="about" className="py-20 bg-gradient-to-br from-rose-50 to-orange-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className={`text-4xl lg:text-5xl font-bold mb-8 bg-gradient-to-r from-rose-600 to-orange-600 bg-clip-text text-transparent ${language === 'ar' ? 'font-arabic' : ''}`}>
              {t('aboutTitle')}
            </h2>
            <p className={`text-lg leading-relaxed text-gray-700 mb-8 ${language === 'ar' ? 'font-arabic' : ''}`}>
              {t('aboutDescription')}
            </p>
            <div className="grid grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">300+</div>
                <div className={`text-sm text-gray-600 ${language === 'ar' ? 'font-arabic' : ''}`}>
                  {language === 'ar' ? 'معلم أثري' : 'Monuments'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600 mb-2">2000+</div>
                <div className={`text-sm text-gray-600 ${language === 'ar' ? 'font-arabic' : ''}`}>
                  {language === 'ar' ? 'سنة تاريخ' : 'Years History'}
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-rose-600 mb-2">1985</div>
                <div className={`text-sm text-gray-600 ${language === 'ar' ? 'font-arabic' : ''}`}>
                  {language === 'ar' ? 'تراث يونسكو' : 'UNESCO Site'}
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              <img
                src="https://images.pexels.com/photos/12661624/pexels-photo-12661624.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                alt="Petra landscape"
                className="w-full h-96 object-cover hover:scale-110 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
            </div>
            <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-gradient-to-br from-rose-500 to-orange-500 rounded-full opacity-20"></div>
            <div className="absolute -top-6 -left-6 w-16 h-16 bg-gradient-to-br from-orange-500 to-rose-500 rounded-full opacity-20"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;